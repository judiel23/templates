<?php
/**
 * Magento
 *
 * @author    Meigeeteam http://www.meaigeeteam.com <nick@meaigeeteam.com>
 * @copyright Copyright (C) 2010 - 2012 Meigeeteam
 *
 */
class Meigee_ThemeOptionsBizarre_Block_Adminhtml_System_Config_Form_Field_Font2 extends Mage_Adminhtml_Block_System_Config_Form_Field
{
    /**
     * Override field method to add js
     *
     * @param Varien_Data_Form_Element_Abstract $element
     * @return String
     */
    protected function _getElementHtml(Varien_Data_Form_Element_Abstract $element)
    {
        // Get the default HTML for this option
        $html = parent::_getElementHtml($element);

        $html .= '<br/><div id="themeoptionsbizarre_gfont_preview" style="font-size:20px; margin-top:5px;">The quick brown fox jumps over the lazy dog</div>
		<script>
        var googleFontPreviewModel = Class.create();

        googleFontPreviewModel.prototype = {
            initialize : function()
            {
				if($("meigee_bizarre_design_appearance_gfont")){
					this.fontElement = $("meigee_bizarre_design_appearance_gfont");
				} else if($("meigee_bizarre_design_skin1_appearance_gfont")) {
					this.fontElement = $("meigee_bizarre_design_skin1_appearance_gfont");
				} else if($("meigee_bizarre_design_skin2_appearance_gfont")) {
					this.fontElement = $("meigee_bizarre_design_skin2_appearance_gfont");
				} else if($("meigee_bizarre_design_skin3_appearance_gfont")) {
					this.fontElement = $("meigee_bizarre_design_skin3_appearance_gfont");
				} else if($("meigee_bizarre_design_skin4_appearance_gfont")) {
					this.fontElement = $("meigee_bizarre_design_skin4_appearance_gfont");
				} else if($("meigee_bizarre_design_skin5_appearance_gfont")) {
					this.fontElement = $("meigee_bizarre_design_skin5_appearance_gfont");
				} else if($("meigee_bizarre_design_skin6_appearance_gfont")) {
					this.fontElement = $("meigee_bizarre_design_skin6_appearance_gfont");
				}
                this.previewElement = $("themeoptionsbizarre_gfont_preview");
                this.loadedFonts = "";

                this.refreshPreview();
                this.bindFontChange();
            },
            bindFontChange : function()
            {
                Event.observe(this.fontElement, "change", this.refreshPreview.bind(this));
                Event.observe(this.fontElement, "keyup", this.refreshPreview.bind(this));
                Event.observe(this.fontElement, "keydown", this.refreshPreview.bind(this));
            },
        	refreshPreview : function()
            {
                if ( this.loadedFonts.indexOf( this.fontElement.value ) > -1 ) {
                    this.updateFontFamily();
                    return;
                }

        		var ss = document.createElement("link");
        		ss.type = "text/css";
        		ss.rel = "stylesheet";
        		ss.href = "http://fonts.googleapis.com/css?family=" + this.fontElement.value;
        		document.getElementsByTagName("head")[0].appendChild(ss);

                this.updateFontFamily();

                this.loadedFonts += this.fontElement.value + ",";
            },
            updateFontFamily : function()
            {
                $(this.previewElement).setStyle({ fontFamily: this.fontElement.value });
            }
        }

        googleFontPreview = new googleFontPreviewModel();
		</script>
        ';
        return $html;
    }
}