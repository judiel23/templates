<?php
class IWD_Opc_Block_Onepage_Comment extends  Mage_Core_Block_Template{
	
	public function _construct(){
		$this->setTemplate('opc/onepage/comment.phtml');
	} 
	
}