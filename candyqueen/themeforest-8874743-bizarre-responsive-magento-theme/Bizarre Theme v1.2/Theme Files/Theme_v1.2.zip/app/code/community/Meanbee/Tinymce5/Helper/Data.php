<?php
/**
 * Meanbee_Tinymce5
 *
 * This module was developed by Meanbee Internet Solutions.  If you require any
 * support or have any questions please contact us at support@meanbee.com.
 *
 * @category   Meanbee
 * @package    Meanbee_Tinymce5
 * @author     Meanbee Internet Solutions <support@meanbee.com>
 * @copyright  Copyright (c) 2011 Meanbee Internet Solutions (http://www.meanbee.com)
 * @license    OSL v3.0
 */
class Meanbee_Tinymce5_Helper_Data extends Mage_Core_Helper_Abstract {
    
}
